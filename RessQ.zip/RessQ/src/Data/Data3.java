package Data;

public class Data3 {
  public static Integer id;
}

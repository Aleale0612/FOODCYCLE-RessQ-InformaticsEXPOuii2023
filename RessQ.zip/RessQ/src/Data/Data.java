package Data;

public class Data {

  public static String username;
  public static String path;
  public static Integer id;
  public static String namaLengkap;
}
package Data;

public class Data2 {
  public static Integer id;
}

package Data;

public class Data1 {
  public static String path;
  public static Integer id;
}
